package views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

import entities.Ennemie;
import entities.Personnage;
import gameflow.MapUtils;

public class LayerCharacters extends View{

    private Personnage p;
    private ArrayList<Ennemie> ennemies;
    private ArrayList<Rect> murs, items;
    private int[][] map;
    private boolean start = false;
    Context ctx;

    public LayerCharacters(Context context, int[][] map) {
        super(context);
        ctx = context;

        p = new Personnage(ctx);
        ennemies = new ArrayList<>();
        murs = new ArrayList<>();
        this.map = map;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int x_touch = (int) event.getX();
        int y_touch = (int) event.getY();

        Rect bound = new Rect(x_touch, y_touch, x_touch+p.getSize_width(), y_touch+p.getSize_height());

        boolean collision = false;
        for (int i = 0; i < murs.size() && !collision; i++) {
            if(murs.get(i).intersect(bound))
            {
                collision = true;
                Log.d("test", "onTouchEvent: ne touche pas");
            }
        }

        if(!collision)
        {
            p.putXAndY(x_touch,y_touch);
            invalidate();
        }

        /*for (Ennemie e : ennemies) {
            if(e.getmRectangle().intersect(bound))
            {
                Toast.makeText(ctx, "Ennemi touché", Toast.LENGTH_SHORT).show();
                invalidate();
            }
        }*/

        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!start) {

            int displayW = getWidth();
            int displayH = getHeight();

            int totalW = MapUtils.getImg_width(ctx)*9;
            int totalH = MapUtils.getImg_height(ctx)*7;

            double coeffW = (double)displayW/totalW;
            double coeffH = (double)displayH/totalH;

            for (int i = 0; i < map.length; i++) {
                for (int j = 0; j < map[i].length; j++) {
                    int val = map[i][j];
                    Rect position;

                    if (val == 0) {
                        position = new Rect((int) ((j * MapUtils.getImg_width(ctx))*coeffW), (int) ((i * MapUtils.getImg_height(ctx))*coeffH), (int) (((j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx))*coeffW), (int) (((i *MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx))*coeffH));
                        p.setmRectangle(position);
                        canvas.drawBitmap(p.getImg(), null, position, null);
                    } else if (val == 3) {

                        Ennemie e = new Ennemie(ctx);
                        position = new Rect((int) ((j * MapUtils.getImg_width(ctx))*coeffW), (int) ((i * MapUtils.getImg_height(ctx))*coeffH), (int) (((j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx))*coeffW), (int) (((i *MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx))*coeffH));

                        e.setmRectangle(position);
                        ennemies.add(e);

                        canvas.drawBitmap(e.getImg(), null, position, null);
                    } else if (val == 5) {
                        position = new Rect((int) ((j * MapUtils.getImg_width(ctx))*coeffW), (int) ((i * MapUtils.getImg_height(ctx))*coeffH), (int) (((j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx))*coeffW), (int) (((i *MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx))*coeffH));

                        murs.add(position);
                    }
                }
            }
            start = true;
        }
        else
        {
            canvas.drawBitmap(p.getImg(), null, p.getmRectangle(), null);
            for (Ennemie e: ennemies) {
                canvas.drawBitmap(e.getImg(), null, e.getmRectangle(), null);
            }
        }
    }
}