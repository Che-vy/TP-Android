package com.chev.tptests;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.GridLayout;

public class LvlGrid extends GridLayout {


    public LvlGrid(Context context) {
        super(context);
        setRowCount(5);
        setColumnCount(7);
        setRowOrderPreserved(true);
        setColumnOrderPreserved(true);
        for(int i = 0; i < 35; i++){
            LvlFloor fl = new LvlFloor(context, i);
            addView(fl);
        }
    }

    public LvlGrid(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        MeasureSpec.makeMeasureSpec(metrics.widthPixels/6, MeasureSpec.EXACTLY);
        widthSpec = getWidth()/6;
        heightSpec = getHeight()/5;
        setMeasuredDimension(metrics.widthPixels, metrics.heightPixels);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);


    }
}
