package com.chev.tptests;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

public class LayerBg extends View {

    private Bitmap img, tileset;
    int img_width, img_height;
    private int[][] map;

    public LayerBg(Context context, int[][] map) {
        super(context);

        tileset = BitmapFactory.decodeResource(context.getResources(), R.drawable.tileset);
        img_width = tileset.getWidth()/6;
        img_height = tileset.getHeight();
        this.map = map;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        for(int i = 0; i<map.length;i++)
        {
            for(int j = 0; j<map[i].length; j++)
            {
                int val = map[i][j];

                img = Bitmap.createBitmap(tileset, ((val==0?4:val==3?4:val)*img_width), 0, img_width, img_height);

                Rect position = new Rect((j*img_width),(i*img_height),(j*img_width)+img_width, (i*img_height)+img_height);

                canvas.drawBitmap(img,null,position,null);

            }
        }
    }
}
