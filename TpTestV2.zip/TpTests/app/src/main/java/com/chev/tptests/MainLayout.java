package com.chev.tptests;

import android.content.Context;
import android.widget.RelativeLayout;

public class MainLayout extends RelativeLayout {

    LayerBg bg;
    LayerCharacters lc;
    LayerPath lp;

    public MainLayout(Context context, int[][]  map) {
        super(context);

        bg = new LayerBg(context,map);
        lc = new LayerCharacters(context,map);
        lp = new LayerPath(context,map);
        addView(bg);
        addView(lc);
        addView(lp);
    }
}
