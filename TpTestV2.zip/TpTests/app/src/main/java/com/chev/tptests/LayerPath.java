package com.chev.tptests;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class LayerPath extends View {

    private ArrayList<Rect> murs;
    private int[][] map;
    Context ctx;
    Path path;
    Paint paint;

    public LayerPath(Context context,int[][] map) {
        super(context);

        murs = new ArrayList<>();
        this.map = map;
        ctx = context;

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                int val = map[i][j];
                Rect position;
                if (val == 5) {
                    position = new Rect((j *MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i * MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));

                    murs.add(position);
                }
            }
        }

        paint = new Paint();
        paint.setColor(Color.argb(100,255,255,255));
        paint.setStrokeWidth(MapUtils.getImg_width(ctx)/2);
        paint.setStyle(Paint.Style.STROKE);

        path = new Path();
        path.moveTo(50, 50);
        path.lineTo(50, 500);
        path.lineTo(200, 500);
        path.lineTo(200, 300);
        path.lineTo(350, 300);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPath(path, paint);
    }
}
