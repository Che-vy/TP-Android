package com.chevy.tp_android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu_activity extends Activity {

    Context ctx;
    Button btn_startgame;
    Button btn_stageselect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainmenu_layout);

        ctx = this;
        btn_startgame = findViewById(R.id.btn_startgame);
        btn_stageselect = findViewById(R.id.btn_stageselect);

        btn_startgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, MainActivity.class));
            }
        });
    }
}
