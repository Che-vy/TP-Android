package Views;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

import com.chevy.tp_android.R;

public class Wrapper extends LinearLayout {


    private LinearLayout ll, ll2;
    private LvlGrid lvlGrid;
    private ItemsAndOptions itemsAndOptions;

    public Wrapper(Context context) {
        super(context);
        setOrientation(HORIZONTAL);
        LayoutInflater inflater = LayoutInflater.from(context);
        View fullView = inflater.inflate(R.layout.wrapper_layout, this);

        ll = fullView.findViewById(R.id.layout_grid);
        ll2 = fullView.findViewById(R.id.layout_itemsandoptions);

        lvlGrid = new LvlGrid(context);
        itemsAndOptions = new ItemsAndOptions(context);

        ll.addView(lvlGrid);
        ll2.addView(itemsAndOptions);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

}
