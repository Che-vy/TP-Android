package Views;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.LinearLayout;

public class Wrapper extends LinearLayout {

    private LvlGrid lvlGrid;
    private ItemsAndOptions itemsAndOptions;

    public Wrapper(Context context) {
        super(context);
        lvlGrid = new LvlGrid(context);
        itemsAndOptions = new ItemsAndOptions(context);

        addView(lvlGrid);
        addView(itemsAndOptions);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

}
