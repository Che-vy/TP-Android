package Views;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.chevy.tp_android.R;

import Entities.Item;

//but: conteneur d'item;
//cette classe doit contenir:
//une bordure (image);
//un ImageView et une instance d'item disponible pour insérer l'image de l'item;
//onTouch transmettant l'id de l'item

public class ItemView extends View {

    private ImageView border, itemImage;
    private Item item;
    private Rect frame;

    public ItemView(Context context)
    {
        super(context);
    }

    public ItemView(Context context, int itemId)
    {
        super(context);
        Log.d("debug", "added itemview");
        border = new ImageView(context);
        border.setImageResource(R.drawable.frame_chain);
        itemImage = new ImageView(context);
        item = new Item(context, itemId);

        switch(itemId){
            case 1:
                itemImage.setImageResource(R.drawable.item1);
                break;
            case 2:
                itemImage.setImageResource(R.drawable.item2);
                break;
            case 3:
                itemImage.setImageResource(R.drawable.item3);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.d("debile", "item " + item.getName() + " has been touched");
        switch(item.getEffect()){
            case SHIELD:
                //shieldEffect();
                break;
            case HPGAIN:
                //hpgainEffect();
                break;
            case ATKPLUS:
                //atkplusEffect();
                break;
            case EXPLOSION:
                //explosionEffect();
                break;
            default:
                break;
        }
        return true;
    }


}
