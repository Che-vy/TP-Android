package Views;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.chevy.tp_android.R;

import Entities.Item;

//but: conteneur d'item;
//cette classe doit contenir:
//une bordure (image);
//un ImageView et une instace d'item disponible pour insérer l'image de l'item;
//onTouch transmettant l'id de l'item

public class ItemView extends LinearLayout {

    ImageView itemImage;
    Item item;


    public ItemView(Context context)
    {
        super(context);
    }

    public ItemView(Context context, int itemId)
    {
        super(context);
        itemImage = new ImageView(context);
        item = new Item(context, itemId);
        switch(itemId){
            case 1:
                itemImage.setImageResource(R.drawable.item1);
                break;
            case 2:
                itemImage.setImageResource(R.drawable.item2);
                break;
            case 3:
                itemImage.setImageResource(R.drawable.item3);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }


}
