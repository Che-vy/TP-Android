package Views;

import android.content.Context;
import android.util.Log;
import android.widget.Button;

public class OptionsButton extends Button {

    public OptionsButton(Context context) {
        super(context);
        setText("MENU");
        setTextSize(25);
        Log.d("debug", "added optionsbutton");
    }
}
