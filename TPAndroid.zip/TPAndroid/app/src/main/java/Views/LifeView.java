package Views;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

//classe doit contenir les infos de HP du joueur

public class LifeView extends LinearLayout {

    private int hitPointsCurrent, hitPointsMax;
    private TextView tvHitPoints;

    public LifeView(Context context) {
        super(context);

        tvHitPoints = new TextView(context);
        addView(tvHitPoints);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        tvHitPoints.setText("HP: " + hitPointsCurrent + "/" + hitPointsMax);
    }

    public void hpGain(int amount) {
        hitPointsCurrent += amount;

        if (hitPointsCurrent > hitPointsMax)
            hitPointsCurrent = hitPointsMax;

        postInvalidate();
    }

    public void hpLoss(int amount) {
        hitPointsCurrent -= amount;
        postInvalidate();
        //checkLoseConditionHP();
    }

    public int getHitPointsCurrent() {
        return hitPointsCurrent;
    }

    public void setHitPointsCurrent(int hitPointsCurrent) {
        this.hitPointsCurrent = hitPointsCurrent;
    }

    public int getHitPointsMax() {
        return hitPointsMax;
    }

    public void setHitPointsMax(int hitPointsMax) {
        this.hitPointsMax = hitPointsMax;
    }

    public TextView getTvHitPoints() {
        return tvHitPoints;
    }

    public void setTvHitPoints(TextView tvHitPoints) {
        this.tvHitPoints = tvHitPoints;
    }
}
