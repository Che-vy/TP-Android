package Views;

import android.content.Context;
import android.widget.GridLayout;

import com.chevy.tp_android.R;

import java.util.ArrayList;

public class LvlGrid extends GridLayout {

    private ArrayList<LvlTile> tiles;

    public LvlGrid(Context context) {
        super(context);
        setRowCount(5);
        setColumnCount(6);
        setRowOrderPreserved(true);
        setColumnOrderPreserved(true);
        for(int i = 0; i < 30; i++){
            LvlTile tile = new LvlTile(context, R.drawable.floortiles, 0);
            addView(tile);
        }
    }
}
