package Views;

import android.content.Context;
import android.view.View;

import GameFlow.Constants;

//Classe doit contenir:
//image d'une tuile;
//touchlistener renvoyant son id de tuile correspondant à sa place dans la LvlGrid (à condition que le TileType le permette);
//

public class LvlTile extends View {

    private int imgResource, imgId, gridId;
    private Constants.TileType type;

    public LvlTile(Context context, int imgResource, int id) {
        super(context);
        this.imgResource = imgResource;
        setBackgroundResource(imgResource);


    }


    public int getGridId(){
        return gridId;
    }

    public int getImgId() {
        return imgId;
    }

    public Constants.TileType getType() {
        return type;
    }
}
