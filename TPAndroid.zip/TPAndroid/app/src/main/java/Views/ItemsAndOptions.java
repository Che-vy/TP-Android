package Views;

import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

import com.chevy.tp_android.R;

import java.util.ArrayList;

//cette classe doit contenir:
//conteneur de vues allant à droite de la LvlGrid;
//contient inventaire d'items, info vie du joueur et bouton menu/options
//transmet le onTouch info

public class ItemsAndOptions extends LinearLayout {


    LinearLayout ll;
    private LifeView lifeView;
    private OptionsButton optionsButton;
    private ArrayList<ItemView> itemList;
    private Rect frames;

    public ItemsAndOptions(Context context) {
        super(context);
        Log.d("debug", "added options");
        frames = new Rect(0, 0, getWidth(), getHeight()/5);

        LayoutInflater inflater = LayoutInflater.from(context);
        View fullView = inflater.inflate(R.layout.wrapper_layout, this);

        ll = findViewById(R.id.layout_itemsandoptions);


        itemList = new ArrayList<>();
        itemList.add(new ItemView(context, 2));
        itemList.add(new ItemView(context, 2));
        itemList.add(new ItemView(context, 2));
        lifeView = new LifeView(context);
        optionsButton = new OptionsButton(context);
        for(ItemView iv : itemList){
            addView(iv);
        }
        addView(lifeView);
        addView(optionsButton);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    public void addToItemList(ItemView item){
        itemList.add(item);
    }

    public void removeFromItemList(ItemView item){
        itemList.remove(item);
    }
}
