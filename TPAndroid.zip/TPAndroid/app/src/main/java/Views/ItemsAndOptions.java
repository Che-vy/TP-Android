package Views;

import android.content.Context;
import android.view.MotionEvent;
import android.widget.LinearLayout;

import java.util.ArrayList;

//cette classe doit contenir:
//conteneur de vues allant à droite de la LvlGrid;
//contient inventaire d'items, info vie du joueur et bouton menu/options
//transmet le onTouch info

public class ItemsAndOptions extends LinearLayout {

    private LifeView lifeView;
    private OptionsView optionsView;
    private ArrayList<ItemView> itemList;

    public ItemsAndOptions(Context context) {
        super(context);
//        lifeView = new LifeView(context);
//        optionsView = new OptionsView(context);
//        itemView = new ItemList(context);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    public void addToItemList(ItemView item){
        itemList.add(item);
    }

    public void removeFromItemList(ItemView item){
        itemList.remove(item);
    }
}
