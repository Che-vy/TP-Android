package entities;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.chevy.tp_android.R;

public class Ennemie implements Runnable {

    private Bitmap img;
    private Rect mRectangle = null;
    private int mX, mXDepart, mXDestination, sensX;
    private int mY, mYDepart, mYDestination, sensY;
    private int size_width;
    private int size_height;
    private boolean isFirstTime = true;


    public Ennemie(Context ctx) {
        mRectangle = new Rect();

        Bitmap tileset = BitmapFactory.decodeResource(ctx.getResources(), R.drawable.tileset);
        size_width = tileset.getWidth()/6;
        size_height = tileset.getHeight();

        int tile_x = 3;
        int tile_y = 0;
        sensX = 1;
        sensY = 1;

        img = Bitmap.createBitmap(tileset, tile_x*size_width, tile_y, size_width, size_height);

    }

    public Bitmap getImg() {
        return img;
    }

    public void setImg(Bitmap img) {
        this.img = img;
    }

    public Rect getmRectangle() {
        return mRectangle;
    }

    public void setmRectangle(Rect mRectangle) {
        this.mRectangle = mRectangle;
    }

    public int getmX() {
        return mX;
    }

    public void setmX(int mX) {
        this.mX = mX;
    }

    public int getmY() {
        return mY;
    }

    public void setmY(int mY) {
        this.mY = mY;
    }

    public int getmXDestination() {
        return mXDestination;
    }

    public void setmXDestination(int mXDestination) {
        this.mXDestination = mXDestination;
    }

    public int getmYDestination() {
        return mYDestination;
    }

    public void setmYDestination(int mYDestination) {
        this.mYDestination = mYDestination;
    }

    public int getmXDepart() {
        return mXDepart;
    }

    public void setmXDepart(int mXDepart) {
        this.mXDepart = mXDepart;
    }

    public int getmYDepart() {
        return mYDepart;
    }

    public void setmYDepart(int mYDepart) {
        this.mYDepart = mYDepart;
    }

    public int getSize_width() {
        return size_width;
    }

    public void setSize_width(int size_width) {
        this.size_width = size_width;
    }

    public int getSize_height() {
        return size_height;
    }

    public void setSize_height(int size_height) {
        this.size_height = size_height;
    }

    // Mettre à jour les coordonnées de l'ennemie
    public Rect putXAndY(float pX, float pY) {

        if(isFirstTime){
            mXDepart = (int) pX;
            mYDepart = (int) pY;
        }

        setmX((int) pX);
        setmY((int) pY);

        // Met à jour les coordonnées du rectangle de collision
        mRectangle.set(mX, mY, mX + size_width, mY + size_height);

        return mRectangle;
    }

    @Override
    public void run() {

        setmX(getmX() + (5 * sensX));
        setmY(getmY() + (5 * sensY));




    }
}