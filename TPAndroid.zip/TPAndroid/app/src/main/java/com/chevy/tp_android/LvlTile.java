package com.chevy.tp_android;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;

public class LvlTile extends View {

    int imgResource;

    public LvlTile(Context context, int imgResource) {
        super(context);
        this.imgResource = imgResource;
        setBackgroundResource(imgResource);
    }
}
