package com.chevy.tp_android;

import android.content.Context;
import android.view.View;

public class LifeView extends View {
    public LifeView(Context context) {
        super(context);
    }
}
