package com.chevy.tp_android;

import android.content.Context;
import android.view.View;

public class MenuView extends View {



    public MenuView(Context context) {
        super(context);
    }
}
