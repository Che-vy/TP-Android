package com.chevy.tp_android;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    Wrapper wrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wrapper = new Wrapper(this);
        setContentView(wrapper);
    }
}
