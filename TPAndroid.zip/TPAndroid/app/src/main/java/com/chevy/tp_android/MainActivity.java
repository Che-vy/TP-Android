package com.chevy.tp_android;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import services.PlayTheme;
import views.Wrapper;

public class MainActivity extends Activity {

    private Wrapper wrapper;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        wrapper = new Wrapper(this, 1);
        setContentView(wrapper);

        intent = new Intent(this, PlayTheme.class);
    }

    public void stageTransition(int nextLevel){
        final Wrapper newStage = new Wrapper(this, nextLevel);

        setContentView(newStage);

    }

    @Override
    protected void onResume() {
        startService(intent);
        super.onResume();
    }

    @Override
    protected void onStop() {
        stopService(intent);
        super.onStop();
    }

}
