package com.chevy.tp_android;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

public class Wrapper extends LinearLayout {

    LvlGrid lvlGrid;
    ItemsAndOptions itemsAndOptions;

    public Wrapper(Context context) {
        super(context);
        lvlGrid = new LvlGrid(context);

        addView(lvlGrid);
       // addView(itemsAndOptions);
    }
}
