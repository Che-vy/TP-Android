package com.chevy.tp_android;

import android.content.Context;
import android.widget.LinearLayout;

public class ItemLayout extends LinearLayout {



    public ItemLayout(Context context) {
        super(context);
    }
}
