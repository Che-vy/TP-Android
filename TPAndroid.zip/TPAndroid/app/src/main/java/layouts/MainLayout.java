package layouts;

import android.content.Context;
import android.os.Handler;
import android.widget.RelativeLayout;

import views.LayerBg;
import views.LayerCharacters;
import views.LayerPath;
import views.Wrapper;

public class MainLayout extends RelativeLayout {

    LayerBg bg;
    LayerCharacters lc;
    LayerPath lp;

    public MainLayout(Context context, int[][]  map, Handler handler, Wrapper wrapperLevel) {
        super(context);

        bg = new LayerBg(context,map);
        lc = new LayerCharacters(context,map, handler, wrapperLevel);
        lp = new LayerPath(context,map, lc);
        addView(bg);
        addView(lc);
        addView(lp);
    }
}