package Entities;

import android.content.Context;
import android.widget.LinearLayout;

import GameFlow.Constants;

public class Item extends LinearLayout {

    int id;
    Constants.ItemEffect effect;

    public Item(Context context) {
        super(context);
    }

    public Item(Context context, int id) {
        super(context);
        this.id = id;

        switch (this.id){
            case 1:
                effect = Constants.ItemEffect.JUMP;
                break;
            case 2:
                effect = Constants.ItemEffect.HPGAIN;
                break;
            case 3:
                effect = Constants.ItemEffect.SHIELD;
                break;
            case 4:
                break;
            default:
                break;

        }
    }
}
