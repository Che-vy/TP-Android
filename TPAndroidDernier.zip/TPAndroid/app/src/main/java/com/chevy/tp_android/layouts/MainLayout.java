package com.chevy.tp_android.layouts;

import android.content.Context;
import android.os.Handler;
import android.widget.RelativeLayout;

import com.chevy.tp_android.views.ItemsAndOptions;
import com.chevy.tp_android.views.LayerBg;
import com.chevy.tp_android.views.LayerCharacters;
import com.chevy.tp_android.views.LayerPath;

public class MainLayout extends RelativeLayout {

    LayerBg bg;
    LayerCharacters lc;
    LayerPath lp;
    ItemsAndOptions sidebar;

    public MainLayout(Context context, int[][]  map, Handler handler, Wrapper wrapperLevel, ItemsAndOptions sidebar) {
        super(context);
        this.sidebar = sidebar;
        bg = new LayerBg(context,map);
        lc = new LayerCharacters(context,map, handler, wrapperLevel, sidebar);
        lp = new LayerPath(context,map, lc);
        addView(bg);
        addView(lc);
        addView(lp);
    }
}