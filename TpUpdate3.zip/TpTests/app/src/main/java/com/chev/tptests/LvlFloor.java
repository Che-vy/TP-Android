package com.chev.tptests;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.GridLayout;
import android.widget.ImageView;

public class LvlFloor extends ImageView {

    boolean isBlockingLeft, isBlockingTop, isBlockingRight, isBlockingBottom;
    Bitmap tileset, currentTile;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public LvlFloor(Context context, int start) {
        super(context);
        tileset = BitmapFactory.decodeResource(context.getResources(), R.drawable.floortiles);
        currentTile = Bitmap.createBitmap(tileset, 0, 0, tileset.getWidth()/8, tileset.getHeight()/8);
        setImageBitmap(currentTile);

        GridLayout.LayoutParams param= new GridLayout.LayoutParams(GridLayout.spec(
                GridLayout.UNDEFINED,GridLayout.FILL,1f),
                GridLayout.spec(GridLayout.UNDEFINED,GridLayout.FILL,1f));
        param.height = 0;
        param.width = 0;
        setLayoutParams(param);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            setTooltipText("" + start);
        }

        setBackgroundColor(0xFF251500);
    }

    public LvlFloor(Context context,AttributeSet attrs) {
        super(context, attrs);
        tileset = BitmapFactory.decodeResource(context.getResources(), R.drawable.floortiles);
        currentTile = Bitmap.createBitmap(tileset, 0, 0, tileset.getWidth()/8, tileset.getHeight()/8);

        //setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setImageBitmap(currentTile);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
