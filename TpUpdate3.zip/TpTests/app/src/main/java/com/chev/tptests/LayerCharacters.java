package com.chev.tptests;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.View;

import com.chev.tptests.entities.Ennemie;
import com.chev.tptests.entities.Personnage;

import java.util.ArrayList;

public class LayerCharacters extends View{

    private Personnage p;
    private ArrayList<Ennemie> ennemies;
    private ArrayList<Rect> murs;
    private int[][] map;
    private Context ctx;
    private ArrayList<Point> path;

    public LayerCharacters(Context context, int[][] map) {
        super(context);
        ctx = context;
        p = new Personnage(ctx);
        ennemies = new ArrayList<>();
        murs = new ArrayList<>();
        path = new ArrayList<>();

        this.map = map;

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                int val = map[i][j];
                Rect position;
                if (val == 0) {
                    position = new Rect((j * MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i *MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));
                    p.setBounds(position);
                } else if (val == 3) {
                    Ennemie e = new Ennemie(ctx);
                    position = new Rect((j *MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i * MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));

                    e.setmRectangle(position);
                    ennemies.add(e);
                } else if (val == 5) {
                    position = new Rect((j * MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i * MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));
                    murs.add(position);
                }
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {

        canvas.drawBitmap(p.getImg(), null, p.getmRectangle(), null);
        for (Ennemie e: ennemies) {
            canvas.drawBitmap(e.getImg(), null, e.getmRectangle(), null);
        }
    }

    public Personnage getPersonnage() {
        return p;
    }

    public ArrayList<Point> getPath() {
        return path;
    }
}
