package com.chev.tptests;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.GridLayout;
import android.widget.GridView;

import com.chev.tptests.entities.Bloc;

public class LvlGrid extends GridView {

    private int[][] map;

    public LvlGrid(Context context) {
        super(context);

        map = new int[][]{
                {5, 5, 5, 5, 5, 5, 5, 5, 5}
                , {5, 4, 4, 4, 4, 5, 3, 4, 5}
                , {5, 4, 4, 4, 4, 5, 4, 2, 5}
                , {5, 3, 4, 4, 4, 4, 4, 4, 5}
                , {5, 4, 5, 4, 5, 5, 4, 4, 5}
                , {5, 0, 5, 4, 4, 4, 4, 4, 5}
                , {5, 5, 5, 5, 5, 5, 5, 5, 5}};

        for(int i = 0; i<map.length;i++)
        {
            for(int j = 0; j<map[i].length; j++)
            {
                int val = map[i][j];

                switch (val)
                {
                    case 5:
                        addView(new Bloc(Bloc.Type.MUR,0,0,context));
                        break;

                    case 4:
                        addView(new Bloc(Bloc.Type.CHEMIN,0,0,context));
                        break;

                    case 0:
                        addView(new Bloc(Bloc.Type.CHEMIN,0,0,context));
                        break;

                    case 2:
                        addView(new Bloc(Bloc.Type.ARRIVEE,0,0,context));
                        break;

                }

                //addView(new Bloc(val == 8?true:false,val,context));
            }

        }
    }

    public LvlGrid(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);


    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {


        int action = event.getActionMasked();
        float currentXPosition = event.getX();
        float currentYPosition = event.getY();
        int position = pointToPosition((int) currentXPosition, (int) currentYPosition);

        String s = (String) getItemAtPosition(position);
        Bloc bloc = (Bloc) getChildAt(position);

        Log.d("test", "bloc : "+bloc.toString());

        return true;
    }
}
