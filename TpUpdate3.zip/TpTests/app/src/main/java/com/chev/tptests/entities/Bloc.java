package com.chev.tptests.entities;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.widget.ImageView;

import com.chev.tptests.R;

public class Bloc extends ImageView {

    public enum Type { MUR, CHEMIN, DEPART, ARRIVEE }

    private Type mType = null;
    private int x, y, tilePositionX, tilePositionY, img_height, img_width;
    private Bitmap img, tileset;
    private RectF bounds;


    public Bloc(Type pType, int pX, int pY, Context ctx) {
        super(ctx);
        this.mType = pType;
        this.tilePositionY = 0;

        tileset  = BitmapFactory.decodeResource(ctx.getResources(), R.drawable.tileset);
        img_width = tileset.getWidth()/6;
        img_height = tileset.getHeight();

        this.x = pX;
        this.y = pY;

        switch (mType)
        {
            case MUR:
                this.tilePositionX = 5;
                break;

            case CHEMIN:
                this.tilePositionX = 4;
                break;

            case DEPART:
                this.tilePositionX = 0;
                break;

            case ARRIVEE:
                this.tilePositionX = 2;
                break;
        }

        int tile_x = this.tilePositionX*img_width ;
        int tile_y = this.tilePositionY*img_height;

        img = Bitmap.createBitmap(tileset, tile_x, tile_y, img_width, img_height);
        bounds = new RectF(x,y,x+img_width, y+img_height);

        setImageBitmap(img);
    }

    @Override
    public String toString() {
        return "Bloc{" +
                ", x=" + x +
                ", y=" + y +
                ", tilePositionX=" + tilePositionX +
                ", tilePositionY=" + tilePositionY +
                ", img_height=" + img_height +
                ", img_width=" + img_width +
                ", img=" + img +
                ", tileset=" + tileset +
                ", bounds=" + bounds +
                '}';
    }
}
