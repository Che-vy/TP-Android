package com.chev.tptests;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;

public class MainActivity extends Activity {

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        int[][]  map = MapUtils.getMapByFile("niveau1.txt",this);

        MainLayout mainLayout = new MainLayout(this,map);

        setContentView(mainLayout);

        intent = new Intent(this, PlayTheme.class);
    }

    @Override
    protected void onResume() {
        startService(intent);
        super.onResume();
    }

    @Override
    protected void onStop() {
        stopService(intent);
        super.onStop();
    }
}
