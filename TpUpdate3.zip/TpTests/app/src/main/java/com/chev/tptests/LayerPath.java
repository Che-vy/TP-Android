package com.chev.tptests;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.chev.tptests.entities.Personnage;

import java.util.ArrayList;

public class LayerPath extends View {

    private ArrayList<Rect> murs;
    private int[][] map;
    private Context ctx;
    private Path path;
    private Paint paint;
    private Personnage p;
    private Rect finish;
    private boolean touchFinish = false;
    ArrayList<Point> pathCharacter;

    public LayerPath(Context context,int[][] map, Personnage p, ArrayList<Point> pathCharacter) {
        super(context);

        murs = new ArrayList<>();
        this.map = map;
        ctx = context;
        this.p = p;
        this.pathCharacter = pathCharacter;

        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[i].length; j++) {
                int val = map[i][j];
                Rect position;
                if (val == 5) {
                    position = new Rect((j *MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i * MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));
                    murs.add(position);
                }
                else if(val == 2)
                {
                    position = new Rect((j *MapUtils.getImg_width(ctx)), (i * MapUtils.getImg_height(ctx)), (j * MapUtils.getImg_width(ctx)) + MapUtils.getImg_width(ctx), (i * MapUtils.getImg_height(ctx)) + MapUtils.getImg_height(ctx));
                    finish = position;
                }
            }
        }

        paint = new Paint();
        paint.setColor(Color.argb(125,0,0,0));
        paint.setStrokeWidth(MapUtils.getImg_width(ctx)/3);
        paint.setStyle(Paint.Style.STROKE);

        path = new Path();
        path.moveTo(p.getmRectangle().centerX(), p.getmRectangle().centerY());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x_touch = (int) event.getX();
        int y_touch = (int) event.getY();

        if(event.getActionMasked()== MotionEvent.ACTION_MOVE) {
            if (!touchFinish) {
                boolean collision = false;
                for (int i = 0; i < murs.size() && !collision; i++) {
                    if (murs.get(i).contains(x_touch, y_touch)) {
                        collision = true;
                    }
                }
                if (!collision) {
                    path.lineTo(x_touch,y_touch);
                    pathCharacter.add(new Point(x_touch,y_touch));
                    invalidate();
                }

                if (finish.contains(x_touch, y_touch)) {
                    touchFinish = true;
                }
            }
        }
        else
        {
            Log.d("test", "onTouchEvent: "+pathCharacter);
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
            canvas.drawPath(path, paint);
    }
}
