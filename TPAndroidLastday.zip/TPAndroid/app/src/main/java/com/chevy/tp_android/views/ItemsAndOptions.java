package com.chevy.tp_android.views;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.chevy.tp_android.R;
import com.chevy.tp_android.entities.Personnage;

import java.util.ArrayList;

//cette classe doit contenir:
//conteneur de vues allant à droite de la LvlGrid;
//contient inventaire d'items, info vie du joueur et bouton menu/options
//transmet le onTouch info

public class ItemsAndOptions extends LinearLayout {

    private static ItemsAndOptions instance = null;

    LinearLayout ll = null, ll2 = null, ll3 = null;
    ImageView v1, v2, v3;
    static ImageView imgLife;
    private LifeView lifeView;
    private OptionsButton optionsButton;
    private ArrayList<ItemView> itemList;
    private Rect frames;
    Context ctx;
    Personnage p;

    private ItemsAndOptions(Context context) {
        super(context);
        ctx = context;
        setBackgroundColor(Color.GRAY);

        LayoutInflater inflater = LayoutInflater.from(context);
        View fullView = inflater.inflate(R.layout.itemsandoptions_layout, this);

        ll = fullView.findViewById(R.id.ll_itemsandoptions);
        imgLife = fullView.findViewById(R.id.ll_lifeview);
        ll3 = fullView.findViewById(R.id.ll_optionsbutton);

        v1 = fullView.findViewById(R.id.view1);
        v2 = fullView.findViewById(R.id.view2);
        v3 = fullView.findViewById(R.id.view3);
        v1.setImageResource(R.drawable.frame_chain);
        v2.setImageResource(R.drawable.frame_chain);
        v3.setImageResource(R.drawable.frame_chain);
        imgLife.setImageResource(R.drawable.twohearts);

        itemList = new ArrayList<>();
        itemList.add(null);
        itemList.add(null);
        itemList.add(null);
        lifeView = new LifeView(context);
        optionsButton = new OptionsButton(context);
        p = null;

        updateInventorySlot(0, true, new ItemView(ctx, 2));
        updateInventorySlot(1, true, new ItemView(ctx, 3));
        updateInventorySlot(2, true, new ItemView(ctx, 1));
        v1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemList.get(0) != null){
                    updateInventorySlot(0, false, itemList.get(0), getP());
                }
            }
        });
        v2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemList.get(1) != null){
                    updateInventorySlot(1, false, itemList.get(1), getP());
                }
            }
        });
        v3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(itemList.get(2) != null){
                    updateInventorySlot(2, false, itemList.get(2), getP());
                }
            }
        });

        ll3.addView(optionsButton);
    }

    public void updateInventorySlot(int position, boolean isItemAdded, ItemView item) {
        switch (position) {
            case 0:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v1.setImageResource(R.drawable.item1);
                } else {
                    //activateeffect(item.getEffect());
                    removeFromItemList(position);
                    v1.setImageResource(R.drawable.frame_chain);
                }
                break;
            case 1:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v2.setImageResource(R.drawable.item2);
                } else {
                    //activateeffect(item.getEffect());
                    removeFromItemList(position);
                    v2.setImageResource(R.drawable.frame_chain);
                }
                break;
            case 2:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v3.setImageResource(R.drawable.item3);
                } else {
                    //activateeffect(item.getEffect());
                    removeFromItemList(position);
                    v3.setImageResource(R.drawable.frame_chain);
                }
                break;
            default:
                break;
        }
        postInvalidate();
    }

    public void updateInventorySlot(int position, boolean isItemAdded, ItemView item, Personnage p) {
        switch (position) {
            case 0:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v1.setImageResource(R.drawable.item1);
                } else {
                    p.setVitesse(50);
                    removeFromItemList(position);
                    v1.setImageResource(R.drawable.frame_chain);
                }
                break;
            case 1:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v2.setImageResource(R.drawable.item2);
                } else {
                    p.setLifetotal(4);
                    updateLifeTotal(p.getLifetotal());
                    removeFromItemList(position);
                    v2.setImageResource(R.drawable.frame_chain);
                }
                break;
            case 2:
                if (isItemAdded) {
                    addToItemList(position, item);
                    v3.setImageResource(R.drawable.item3);
                } else {
                    p.setInvincible(true);
                    removeFromItemList(position);
                    v3.setImageResource(R.drawable.frame_chain);
                }
                break;
            default:
                break;
        }
        postInvalidate();
    }

    public void updateLifeTotal(int lifeTotal){
        switch (lifeTotal){
            case 0:
                imgLife.setImageResource(R.drawable.emptyheart);
                break;
            case 1:
                imgLife.setImageResource(R.drawable.halfheart);
                break;
            case 2:
                imgLife.setImageResource(R.drawable.fullheart);
                break;
            case 3:
                imgLife.setImageResource(R.drawable.twoandhalfhearts);
                break;
            case 4:
                imgLife.setImageResource(R.drawable.twohearts);
        }
        postInvalidate();
    }

    public static ItemsAndOptions getInstance(Context ctx){
        if(instance == null) {
            instance = new ItemsAndOptions(ctx);
        }
        else{
            ((ViewGroup)instance.getParent()).removeView(instance);
        }
        return instance;
    }


    public Personnage getP() {
        return p;
    }

    public void setP(Personnage p) {
        this.p = p;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return super.onTouchEvent(event);
    }

    public void addToItemList(int index, ItemView item) {
        itemList.set(index, item);
    }

    public void removeFromItemList(int index) {
        itemList.set(index, null);
    }
}
